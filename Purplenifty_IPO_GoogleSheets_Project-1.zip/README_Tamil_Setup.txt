PURPLENIFTY IPO — GOOGLE SHEETS LIVE DATA SETUP

WHAT THIS DOES
- The APK can remain installed while IPO values are changed in Google Sheets.
- The app reads the sheet through a Google Apps Script web app each time it opens/reloads.
- If online loading fails, the current built-in data remains visible.
- This does NOT automatically verify IPO facts. Update data from reliable sources.

FILES
- index.html: your dashboard updated with a Google Sheets JSONP loader
- Code.gs: Google Apps Script endpoint
- manifest.json, sw.js, icons: PWA support files if present
- Google_Sheets_Headers.csv: column header/template example

ANDROID-ONLY SETUP
1. In Chrome on your Android phone, open https://sheets.google.com and create a spreadsheet.
2. Rename the sheet tab to exactly: IPOs
3. Put these headers in row 1, in this exact spelling/order:
   name, sector, exchange, openDate, closeDate, listingDate, priceLow, priceHigh,
   lotSize, issueSizeCr, gmp, retail, nii, qib, total, type
4. Enter IPO data from row 2. Dates must be formatted yyyy-MM-dd (example 2026-10-24).
   For missing GMP/subscription figures, leave the cell blank. Use numbers only for numeric fields.
5. In the spreadsheet, open Extensions > Apps Script (if the mobile view hides it, use Chrome menu > Desktop site).
6. Delete the starter code and paste all content from Code.gs. Save.
7. Tap Deploy > New deployment > select type "Web app".
8. Set "Execute as" to Me. Set access to "Anyone" if available. Deploy and approve Google permissions.
   This endpoint is publicly readable. Do not put private information in the sheet.
9. Copy the Web app URL ending in /exec.
10. Open this project's index.html in an editor and replace:
    PASTE_YOUR_WEB_APP_URL_HERE
    with the copied URL, keeping the URL inside the quotation marks.
11. Rebuild the APK once with this updated project. After that, change data in Sheets without rebuilding.
12. Open the app while connected to the internet; data loads from Sheets. Reopen/reload the app after edits.

IMPORTANT LIMITATIONS
- First APK build after adding the endpoint is required. Future sheet data changes do not need APK rebuilds.
- This version uses JSONP so the browser can read the Apps Script response without ordinary fetch/CORS issues.
- The current reminder button stores a reminder flag only; it does not create Android notifications.
- Data in the original HTML included sample IPO entries. Replace them with verified information before relying on the dashboard.
