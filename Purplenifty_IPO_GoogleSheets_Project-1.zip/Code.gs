/**
 * Purplenifty IPO - Google Sheets read-only JSONP endpoint
 *
 * Sheet tab name: IPOs
 * Row 1 headers must be exactly:
 * name | sector | exchange | openDate | closeDate | listingDate |
 * priceLow | priceHigh | lotSize | issueSizeCr | gmp |
 * retail | nii | qib | total | type
 *
 * Format openDate, closeDate, listingDate as yyyy-MM-dd in the sheet.
 * Deploy as a Web app, execute as "Me", access "Anyone".
 * Do not put private/personal information in this public sheet.
 */
function doGet(e) {
  var callback = (e && e.parameter && e.parameter.callback) || "";
  // Allow only a simple JavaScript callback identifier for JSONP.
  if (!/^[A-Za-z_$][0-9A-Za-z_$\.]*$/.test(callback)) {
    return ContentService.createTextOutput("Invalid callback");
  }

  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("IPOs");
  if (!sheet) {
    return ContentService.createTextOutput(callback + "([]);")
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }

  var values = sheet.getDataRange().getDisplayValues();
  if (values.length < 2) {
    return ContentService.createTextOutput(callback + "([]);")
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }

  var headers = values.shift().map(function(h) {
    return String(h).trim();
  });

  var rows = values.filter(function(row) {
    return row.some(function(cell) { return String(cell).trim() !== ""; });
  }).map(function(row) {
    var obj = {};
    headers.forEach(function(header, i) {
      obj[header] = row[i] === undefined ? "" : row[i];
    });
    return obj;
  });

  var output = callback + "(" + JSON.stringify(rows) + ");";
  return ContentService.createTextOutput(output)
    .setMimeType(ContentService.MimeType.JAVASCRIPT);
}
